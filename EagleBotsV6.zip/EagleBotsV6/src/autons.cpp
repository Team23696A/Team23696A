#include "vex.h"

void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(10, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 700);
  chassis.set_turn_exit_conditions(1, 200, 700);
  chassis.set_swing_exit_conditions(1, 200, 700);
}

// void FarSide_constants(){
//   // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
//   chassis.set_drive_constants(12, 1.5, 0, 10, 0);
//   chassis.set_heading_constants(12, .4, 0, 1, 0);
//   chassis.set_turn_constants(12, .4, .03, 3, 15);
//   chassis.set_swing_constants(12, .3, .001, 2, 15);

//   // Each exit condition set is in the form (settle_error, settle_time, timeout).
//   chassis.set_drive_exit_conditions(1.5, 200, 600);
//   chassis.set_turn_exit_conditions(1, 200, 600);
//   chassis.set_swing_exit_conditions(1, 200, 600);
// }

// void CloseSide_constants(){
//   // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
//   chassis.set_drive_constants(12, 1.5, 0, 10, 0);
//   chassis.set_heading_constants(12, .4, 0, 1, 0);
//   chassis.set_turn_constants(12, .4, .03, 3, 15);
//   chassis.set_swing_constants(12, .3, .001, 2, 15);

//   // Each exit condition set is in the form (settle_error, settle_time, timeout).
//   chassis.set_drive_exit_conditions(1.5, 200, 500);
//   chassis.set_turn_exit_conditions(1, 200, 500);
//   chassis.set_swing_exit_conditions(1, 200, 500);
// }

//.set_coordinates works as X coordinate, Y coordinate, orientation (In degrees, 360 degree format)
void TestDrive(){
          // chassis.drive_max_voltage = 12;
          // default_constants();
          // chassis.set_coordinates(0, 0, 25);
          // chassis.drive_distance(100);
          // chassis.drive_distance(-100);
          // chassis.turn_to_angle(90);
          // chassis.drive_distance(100);
          // chassis.drive_distance(-100);
          // chassis.turn_to_angle(180);
          // chassis.drive_distance(100);
          // chassis.drive_distance(-100);
          // chassis.turn_to_angle(270);
          // chassis.drive_distance(100);
          // chassis.drive_distance(-100);
          // chassis.turn_to_angle(0);
          // chassis.drive_distance(100);
          // chassis.drive_distance(-100);
          // chassis.set_coordinates(0, 0, 25);
}

void No_Auton(){
  chassis.drive_max_voltage = 12;
  default_constants();
  chassis.set_coordinates(0, 0, 25);
  wait(0.2, sec);
}

void Red_RHS(){
  default_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.drive_to_point(0, 17.72);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  chassis.turn_to_point(5.08, 35.43);
  chassis.drive_to_point(5.08, 35.43);
  chassis.turn_to_point(29.53, 11.81);
  chassis.drive_to_point(29.53, 11.81);
  LilWill.set(true);
  chassis.turn_to_point(29.53, 5.90);
  chassis.drive_to_point(29.53, 5.90);

}

void Red_LHS(){
 
}

void Blue_LHS(){

}

void Blue_RHS(){

} 


void RedAWP(){

} 
void BlueAWP(){

} 
void Skill_Auton(){

}