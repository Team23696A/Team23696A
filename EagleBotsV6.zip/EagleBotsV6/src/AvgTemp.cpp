#include "vex.h"
#include "globals.h"
void displayAvgTemp(){
  if (Controller1.ButtonUp.pressing()){
      LeftM1Temp = LeftM1.temperature(percentUnits::pct);
      LeftM2Temp = LeftM2.temperature(percentUnits::pct);
      LeftM3Temp = LeftM3.temperature(percentUnits::pct);
      RightM1Temp = LeftM1.temperature(percentUnits::pct);
      RightM2Temp = LeftM2.temperature(percentUnits::pct);
      RightM3Temp = LeftM3.temperature(percentUnits::pct);
      a = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
      Controller1.Screen.clearLine(1);
      Controller1.Screen.setCursor(1,1);
      Controller1.Screen.print("AvgTemp:");
      Controller1.Screen.setCursor(1,10);
      Controller1.Screen.print(a);
    }
}