#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// InertialSensor       inertial      14              
// RightM1              motor         15              
// RightM2              motor         16              
// RightM3              motor         17              
// LeftM1               motor         11              
// LeftM2               motor         12              
// LeftM3               motor         13              
// Intake1              motor         18              
// Intake2              motor         20              
// Intake3              motor         19              
// SW                   digital_out   A               
// LilWill              digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
competition Competition;

/*---------------------------------------------------------------------------*/
/*                             VEXcode Config                                */
/*                                                                           */
/*  Before you do anything else, start by configuring your motors and        */
/*  sensors using the V5 port icon in the top right of the screen. Doing     */
/*  so will update robot-config.cpp and robot-config.h automatically, so     */
/*  you don't have to. Ensure that your motors are reversed properly. For    */
/*  the drive, spinning all motors forward should drive the robot forward.   */
/*---------------------------------------------------------------------------*/

Drive chassis(
//Specify your drive setup below. There are eight options:
//ZERO_TRACKER_NO_ODOM, ZERO_TRACKER_ODOM, TANK_ONE_ENCODER, TANK_ONE_ROTATION, TANK_TWO_ENCODER, TANK_TWO_ROTATION, HOLONOMIC_TWO_ENCODER, and HOLONOMIC_TWO_ROTATION
//For example, if you are not using odometry, put ZERO_TRACKER_NO_ODOM below:
ZERO_TRACKER_NO_ODOM,

//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
motor_group(LeftM1,LeftM2,LeftM3),

//Right Motors:
motor_group(RightM1,RightM2,RightM3),

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT14,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.75,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

/*---------------------------------------------------------------------------*/
/*                                  PAUSE!                                   */
/*                                                                           */
/*  The rest of the drive constructor is for robots using POSITION TRACKING. */
/*  If you are not using position tracking, leave the rest of the values as  */
/*  they are.                                                                */
/*---------------------------------------------------------------------------*/

//PAUSE! The rest of the drive constructor is for robot using POSITION TRACKING.
//If you are not using position tracking, leave the rest of the values as they are.

//Input your drive motors by position. This is only necessary for holonomic drives, otherwise this section can be left alone.
//LF:      //RF:    
PORT1,     -PORT2,

//LB:      //RB: 
PORT3,     -PORT4,

//If you are using position tracking, this is the Forward Tracker port (the tracker which runs parallel to the direction of the chassis).
//If this is a rotation sensor, enter it in "PORT1" format, inputting the port below.
//If this is an encoder, enter the port as an integer. Triport A will be a "1", Triport B will be a "2", etc.
3,

//Input the Forward Tracker diameter (reverse it to make the direction switch):
2.75,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//For a zero tracker tank drive with odom, put the positive distance from the center of the robot to the right side of the drive.
//This distance is in inches:
-2,

//Input the Sideways Tracker Port, following the same steps as the Forward Tracker Port:
1,

//Sideways tracker diameter (reverse to make the direction switch):
-2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
2.75

);




      //Click Stop Here

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  default_constants();
  Start_Screen();
  ScreenPage = 0;
  current_auton_selection = 0;
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("Please Select an Auto");
  while(auto_started == false){ 
    BrainClickedIndicator();
    task::sleep(500);
  }
}

void autonomous(void) {
  auto_started = true;
  switch(current_auton_selection){  
    case 0:
      //No Auton
      No_Auton();
      break;        
    case 1:         
      //Red Right Hand
      Red_RHS();
      break;
    case 2:
      //Red Left Hand
      Red_LHS();
      break;
    case 3:
      //Blue Right Hand
      Blue_RHS();
      break;
    case 4:
      //Blue Left Hand
      Blue_LHS();
      break;
    case 5:
      Skill_Auton();
      break;
    case 6:
      //BlueAWP();
      No_Auton();
      break;
    case 7:
      //RedAWP();
      break;
    case 8:
      //BlueAWP();
      break;
    case 9:
      Blue_Elim();
      break;
    case 10:
      Red_Elim();
      break;
 }
}
void updateIntake() {
  if (IntakeTop) {
    Intake1.setVelocity(100, pct);
    Intake2.setVelocity(100, pct);
    Intake3.setVelocity(100, pct);
    Intake1.spin(forward);
    Intake2.spin(reverse);
    Intake3.spin(forward);
    
  } else if (IntakeLow) {
    Intake1.setVelocity(100, pct);
    Intake2.setVelocity(100, pct);
    Intake3.setVelocity(100, pct);
    Intake1.spin(reverse);
    Intake2.spin(forward);
    Intake3.spin(reverse); 
  } 
  else if (IntakeMid) {
    Intake1.setVelocity(100, pct);
    Intake2.setVelocity(100, pct);
    Intake3.setVelocity(100, pct);
    Intake1.spin(forward);
    Intake2.spin(reverse);
    Intake3.spin(reverse);
  } 
  else if (AJ){
    Intake1.setVelocity(100, pct);
    Intake2.setVelocity(100, pct);
    Intake3.setVelocity(100, pct);
    Intake1.spin(reverse);
    Intake2.spin(reverse);
    Intake3.spin(forward);
  }
  else {
    Intake1.stop();
    Intake2.stop();
    Intake3.stop();
  }
}

void toggleTop() {
  if (!IntakeTop) {  // Activate forward toggle
    IntakeTop = true;
    IntakeLow = false;  // Disable reverse toggle
    IntakeMid = false;
    AJ = false;
  } else {  
    IntakeTop = false;  // Deactivate forward toggle
    IntakeLow = false;
    IntakeMid = false;
    AJ = false;
  }
  updateIntake();  // Update motor based on new state
}

void toggleLow() {
  if (!IntakeLow) {  // Activate reverse toggle
    IntakeLow = true;
    IntakeTop = false;  // Disable reverse toggle
    IntakeMid = false;
    AJ = false;
  } else {
    IntakeLow = false;  // Deactivate reverse toggle
    IntakeMid = false;
    IntakeTop = false;
    AJ = false;
  }
  updateIntake();  // Update motor based on new state
}

void toggleMid() {
  if (!IntakeMid) {  // Activate middle(??) toggle
    IntakeMid = true;
    IntakeLow = false;  // Disable reverse toggle
    IntakeTop = false; 
    AJ = false;
  } else {
    IntakeMid = false;  // Deactivate middle toggle
    IntakeLow = false;  // Disable reverse toggle
    IntakeTop = false; 
    AJ = false;
  }
  updateIntake();  // Update motor based on new state
}

void AJT() {
  if (!AJ) {  // Activate forward toggle
    AJ = true;
    IntakeLow = false;  // Disable reverse toggle
    IntakeTop = false;
    IntakeMid = false;
  } else {
    IntakeMid = false;  // Deactivate middle toggle
    IntakeLow = false;  // Disable reverse toggle
    IntakeTop = false; 
    AJ = false;
  }
  updateIntake();  // Update motor based on new state
}


/*void handlePageSwitching() {
    // Switch pages every 3 seconds
    if (pageTimer.time(seconds) > 5) {
        currentPage = (currentPage == 1) ? 2 : 1; // Toggle between page 1 and 2
        updateControllerUI(); // Update the screen
        pageTimer.reset(); // Reset the timer
    }
}*/


// Function to toggle Intake status
void toggleIntake() {
    intakeStatus = !intakeStatus;
}
/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  We modify the code to add  own robot specific commands here.             */
/*---------------------------------------------------------------------------*/



bool LilToggle = false;
bool SWToggle = false;

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    
    // Since VEXCode doesn't have an equivalent function to 
    // get_digital_new_press, we need to detect the new push 
    // of a controller button. 

    // v v insert toggles below v v 
    chassis.control_arcade();
    
    //Intake Joystick control
    /*if (Controller1.ButtonX.pressing()){
      intake.spin(forward, 100, pct);
    }
    if (Controller1.ButtonA.pressing()){
      intake.spin(reverse, 100, pct);
    }
    */
        
    
    //intake toggle (in addition to the manual joystick control)
    if (Controller1.ButtonUp.pressing()) {
      toggleTop();
      while (Controller1.ButtonUp.pressing()) {
        // Prevent multiple toggles on a single press
        vex::task::sleep(20);
      }
    }
    if (Controller1.ButtonDown.pressing()) {
      toggleLow();
      while (Controller1.ButtonDown.pressing()) {
        // Prevent multiple toggles on a single press
        vex::task::sleep(20);
      }
    }
    if (Controller1.ButtonLeft.pressing()) {
      toggleMid();
      while (Controller1.ButtonLeft.pressing()) {
        // Prevent multiple toggles on a single press
        vex::task::sleep(20);
      }
    }
    if (Controller1.ButtonX.pressing()) {
      AJT();
      while (Controller1.ButtonX.pressing()) {
        // Prevent multiple toggles on a single press
        vex::task::sleep(20);
      }
    }



    if (Controller1.ButtonL1.pressing()){
      if (!(LilToggle)){
        LilToggle = true;}
      else if (LilToggle){
        LilToggle = false;}
      while (Controller1.ButtonL1.pressing()){
        wait(1, msec);}}
      if (LilToggle){
        LilWill.set(true);}
      else if (!(LilToggle)){  
        LilWill.set(false);}
    

    if (Controller1.ButtonR1.pressing()){
      if (!(SWToggle)){
        SWToggle = true;}
      else if (SWToggle){
        SWToggle = false;}
      while (Controller1.ButtonR1.pressing()){
        wait(1, msec);}}
      if (SWToggle){
        SW.set(true);}
      else if (!(SWToggle)){  
        SW.set(false);}
    
    //button to rotate drivetrain a bit to the right
    //if (Controller1.ButtonLeft.pressed() (not implimented yet)
    //average motor temp display
    if (Controller1.ButtonA.pressing()){
      LeftM1Temp = LeftM1.temperature(percentUnits::pct);
      LeftM2Temp = LeftM2.temperature(percentUnits::pct);
      LeftM3Temp = LeftM3.temperature(percentUnits::pct);
      RightM1Temp = LeftM1.temperature(percentUnits::pct);
      RightM2Temp = LeftM2.temperature(percentUnits::pct);
      RightM3Temp = LeftM3.temperature(percentUnits::pct);
      avgDriveTrainTemp = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
      Controller1.Screen.clearLine(1);
      Controller1.Screen.setCursor(1,1);
      Controller1.Screen.print("AvgTemp:");
      Controller1.Screen.setCursor(1,10);
      Controller1.Screen.print(avgDriveTrainTemp);
    }

    if (Controller1.ButtonRight.pressing()){
      //Competition.test_auton();
    }

      
    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
         
  }
}

//
// Main will set up the competition functions and callbacks.
//
bool CompetitionStarted = false;
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  chassis.set_coordinates(0, 0, 0);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
