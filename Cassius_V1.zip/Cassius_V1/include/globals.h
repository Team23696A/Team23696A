#include <string>
//Screen 1 (Home Page)
void drawLogo();
void Start_Screen();

//Screen 2 (Auton Selection)
void AutonomousSelection();
void Red_Auton_Screen();
void Blue_Auton_Screen();

//Robot Stats
void DeviceInfoScreen();

//debug screen (not operational yet)
void DebugScreen();

//screen clicking detection system
void BrainClickedIndicator();

//variable for 
extern int ScreenPage;

extern int LeftM1Temp;
extern int LeftM2Temp;
extern int LeftM3Temp;
extern int RightM1Temp;
extern int RightM2Temp;
extern int RightM3Temp;
extern bool ToggleTempDisplay;

//Average Temperture calc
extern int a;
void displayAvgTemp();

//Autons
extern bool auto_started;
void Blue_LHS();
void Blue_RHS();
void Red_LHS();
void Red_RHS();
void RedRush();
void BlueRush();
void Skill_Auton();
void No_Auton();
void default_constants();

//Debug
void DrivetrainTest();
void IntakeTest();
void BatteryStatusScreen();
void ScreenTest();
void PneumaticsTest();
void ToggleTest();
void TestDrive();

//auton selection
extern std::string autonSelected;
extern int current_auton_selection;

//intake toggles
extern bool toggleIntakeF;
extern bool toggleIntakeR;
