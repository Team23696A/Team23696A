#include "vex.h"
void DrivetrainTest(){
  Controller1.rumble("---");
  wait(1, sec);
  Controller1.rumble("---");
  wait(1, sec);
  Controller1.rumble("---");
  wait(1, sec);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(90);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(180);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(270);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(0);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  
}
void IntakeTest(){
  
}
void ScreenTest(){
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(0, 0, 490, 282);
  wait(3, sec);
  Brain.Screen.clearScreen();
  Brain.Screen.setFillColor(blue);
  Brain.Screen.drawRectangle(0, 0, 490, 282);
    wait(3, sec);
  Brain.Screen.clearScreen();
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(0, 0, 490, 282);
    wait(3, sec);
  Brain.Screen.clearScreen();
  DebugScreen();
  ScreenPage=5;
}
void PneumaticsTest(){

}
void ToggleTest(){

}