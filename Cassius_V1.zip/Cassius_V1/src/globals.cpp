#include "globals.h"
int current_auton_selection = 0;
int a = 0;
int ScreenPage = 0;
bool auto_started = false;

std::string autonSelected = "No Auton";
int LeftM1Temp = 0;
int LeftM2Temp = 0;
int LeftM3Temp = 0;
int RightM1Temp = 0;
int RightM2Temp = 0;
int RightM3Temp = 0;

bool ToggleTempDisplay = false;
bool ToggleIntake = false;

bool toggleIntakeF = false;
bool toggleIntakeR = false;

