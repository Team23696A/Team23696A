#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void No_Auton();
void CloseSide_Short_Auton();
void CloseSide_Long_Auton();
void FarSide_Short_Auton();
void FarSide_Long_Auton();
void Skill_Auton();

void drive_test();
void turn_test();
void swing_test();
void full_test();
void odom_test();
void tank_odom_test();
void holonomic_odom_test();