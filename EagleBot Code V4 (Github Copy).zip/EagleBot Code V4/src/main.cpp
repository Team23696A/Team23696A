#include "vex.h"

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// InertialSensor       inertial      18              
// puncherMotor         motor         10              
// leftFrontWing        digital_out   C               
// rightFrontWing       digital_out   D               
// leftBackWing         digital_out   A               
// rightBackWing        digital_out   B               
// intakeMotor          motor         2               
// RightM1              motor         11              
// RightM2              motor         12              
// RightM3              motor         13              
// LeftM1               motor         14              
// LeftM2               motor         15              
// LeftM3               motor         16              
// IntakeHolder         digital_out   E               
// ---- END VEXCODE CONFIGURED DEVICES ----

using namespace vex;
competition Competition;

/*---------------------------------------------------------------------------*/
/*                             VEXcode Config                                */
/*                                                                           */
/*  Before you do anything else, start by configuring your motors and        */
/*  sensors using the V5 port icon in the top right of the screen. Doing     */
/*  so will update robot-config.cpp and robot-config.h automatically, so     */
/*  you don't have to. Ensure that your motors are reversed properly. For    */
/*  the drive, spinning all motors forward should drive the robot forward.   */
/*---------------------------------------------------------------------------*/

Drive chassis(
//Specify your drive setup below. There are eight options:
//ZERO_TRACKER_NO_ODOM, ZERO_TRACKER_ODOM, TANK_ONE_ENCODER, TANK_ONE_ROTATION, TANK_TWO_ENCODER, TANK_TWO_ROTATION, HOLONOMIC_TWO_ENCODER, and HOLONOMIC_TWO_ROTATION
//For example, if you are not using odometry, put ZERO_TRACKER_NO_ODOM below:
ZERO_TRACKER_ODOM,

//Add the names of your Drive motors into the motor groups below, separated by commas, i.e. motor_group(Motor1,Motor2,Motor3).
//You will input whatever motor names you chose when you configured your robot using the sidebar configurer, they don't have to be "Motor1" and "Motor2".

//Left Motors:
motor_group(LeftM1,LeftM2,LeftM3),

//Right Motors:
motor_group(RightM1,RightM2,RightM3),

//Specify the PORT NUMBER of your inertial sensor, in PORT format (i.e. "PORT1", not simply "1"):
PORT18,

//Input your wheel diameter. (4" omnis are actually closer to 4.125"):
3.25,

//External ratio, must be in decimal, in the format of input teeth/output teeth.
//If your motor has an 84-tooth gear and your wheel has a 60-tooth gear, this value will be 1.4.
//If the motor drives the wheel directly, this value is 1:
0.6,

//Gyro scale, this is what your gyro reads when you spin the robot 360 degrees.
//For most cases 360 will do fine here, but this scale factor can be very helpful when precision is necessary.
360,

/*---------------------------------------------------------------------------*/
/*                                  PAUSE!                                   */
/*                                                                           */
/*  The rest of the drive constructor is for robots using POSITION TRACKING. */
/*  If you are not using position tracking, leave the rest of the values as  */
/*  they are.                                                                */
/*---------------------------------------------------------------------------*/

//PAUSE! The rest of the drive constructor is for robot using POSITION TRACKING.
//If you are not using position tracking, leave the rest of the values as they are.

//Input your drive motors by position. This is only necessary for holonomic drives, otherwise this section can be left alone.
//LF:      //RF:    
PORT1,     -PORT2,

//LB:      //RB: 
PORT3,     -PORT4,

//If you are using position tracking, this is the Forward Tracker port (the tracker which runs parallel to the direction of the chassis).
//If this is a rotation sensor, leave it in "PORT1" format, inputting the port below.
//If this is an encoder, enter the port as an integer. Triport A will be a "1", Triport B will be a "2", etc.
3,

//Input the Forward Tracker diameter (reverse it to make the direction switch):
3.25,

//Input Forward Tracker center distance (a positive distance corresponds to a tracker on the right side of the robot, negative is left.)
//This distance is in inches:
5.5,

//Input the Sideways Tracker Port, following the same steps as the Forward Tracker Port:
1,

//Sideways tracker diameter (reverse to make the direction switch):
-2.75,

//Sideways tracker center distance (positive distance is behind the center of the robot, negative is in front):
5.5

);

int current_auton_selection = 0;
int ScreenPage = 0;
int ScreenPressedIndicator = 0;
bool auto_started = false;
void Start_Screen() {         //Start Screen
  Brain.Screen.clearScreen();     
  Brain.Screen.setPenColor(green);
  Brain.Screen.setFillColor(black);
  Brain.Screen.setFont(vex::fontType::mono60);
  Brain.Screen.printAt(170, 85, "Eagle");
  Brain.Screen.setFont(vex::fontType::mono30);
  Brain.Screen.printAt(200, 125, "23696A");
  Brain.Screen.setFont(vex::fontType::mono30);
  Brain.Screen.printAt(55, 155, "Washington Middle School");
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(80, 180, 154, 37);
  Brain.Screen.drawRectangle(250, 180, 154, 37);
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFont(vex::fontType::mono20);
  Brain.Screen.printAt(105, 205, "Autonomous");
  Brain.Screen.printAt(270, 205, "PID Status");

}
void AutonomousSelection(){
  Brain.Screen.clearScreen();
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor({97, 97, 97});
  Brain.Screen.drawRectangle(0, 0, 343, 240);
  Brain.Screen.drawImageFromFile("Field.png", 0, 0);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(358, 27, 101, 35);
  Brain.Screen.drawRectangle(358, 69, 101, 35);
  Brain.Screen.drawRectangle(358, 111, 101, 35);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(358, 179, 101, 35);
  Brain.Screen.setFillColor(green);
  Brain.Screen.setFont(vex::fontType::mono20);
  Brain.Screen.setPenColor(white);
  Brain.Screen.printAt(365, 50, "No Auton");
  Brain.Screen.printAt(380, 90, "CloseSide");
  Brain.Screen.printAt(380, 135, "FarSide");
  Brain.Screen.setFillColor(red);
  Brain.Screen.printAt(380, 200, "Close");
  Brain.Screen.setFillColor({97, 97, 97});
  Brain.Screen.setFont(vex::fontType::mono30);
  Brain.Screen.printAt(80, 130, "Chose the side");
}

void CloseSide_Auto_Screen (){
  Brain.Screen.clearScreen();
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor({97, 97, 97});
  Brain.Screen.drawRectangle(0, 0, 343, 240);
  Brain.Screen.drawImageFromFile("Field.png", 0, 0);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(358, 27, 101, 35);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(358, 69, 101, 35);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(358, 111, 101, 35);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(358, 179, 101, 35);
  Brain.Screen.setFillColor(green);
  Brain.Screen.setFont(vex::fontType::mono20);
  Brain.Screen.setPenColor(white);
  Brain.Screen.printAt(365, 50, "No Auton");
  Brain.Screen.setFillColor(red);
  Brain.Screen.printAt(380, 90, "CloseSide");
  Brain.Screen.setFillColor(green);
  Brain.Screen.printAt(380, 135, "FarSide");
  Brain.Screen.setFillColor(red);
  Brain.Screen.printAt(380, 200, "Close");
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(239, 6, 102, 111);
  Brain.Screen.drawRectangle(239, 123, 102, 111);
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFont(vex::fontType::mono30);
  Brain.Screen.printAt(255 ,65, "Long");
  Brain.Screen.printAt(255 ,180, "Short");
}
void FarSide_Auto_Screen (){
  Brain.Screen.clearScreen();
  Brain.Screen.setPenColor(black);
  Brain.Screen.setFillColor({97, 97, 97});
  Brain.Screen.drawRectangle(0, 0, 343, 240);
  Brain.Screen.drawImageFromFile("Field.png", 0, 0);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(358, 27, 101, 35);
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(358, 69, 101, 35);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(358, 111, 101, 35);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(358, 179, 101, 35);
  Brain.Screen.setFillColor(green);
  Brain.Screen.setFont(vex::fontType::mono20);
  Brain.Screen.setPenColor(white);
  Brain.Screen.printAt(365, 50, "No Auton");
  Brain.Screen.setFillColor(green);
  Brain.Screen.printAt(380, 90, "CloseSide");
  Brain.Screen.setFillColor(red);
  Brain.Screen.printAt(380, 135, "FarSide");
  Brain.Screen.setFillColor(red);
  Brain.Screen.printAt(380, 200, "Close");
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(239, 6, 102, 111);
  Brain.Screen.drawRectangle(239, 123, 102, 111);
  Brain.Screen.setPenColor(white);
  Brain.Screen.setFont(vex::fontType::mono30);
  Brain.Screen.printAt(255 ,65, "Long");
  Brain.Screen.printAt(255 ,180, "Short");
}
void DeviceInfoScreen(){
  Brain.Screen.clearScreen();
  while(ScreenPage == 4) {
    Brain.Screen.clearScreen();
    Brain.Screen.setPenColor(black);
    Brain.Screen.setFillColor({97, 97, 97});
    Brain.Screen.drawRectangle(0, 0, 343, 240);
    Brain.Screen.setFont(vex::fontType::mono20);
    Brain.Screen.setPenColor(red);
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawRectangle(358, 179, 101, 35);
    Brain.Screen.setPenColor(white);
    Brain.Screen.printAt(380, 200, "Close");
    Brain.Screen.setPenColor(green);
    Brain.Screen.setFillColor(green);
    Brain.Screen.drawRectangle(13, 19, 302, 33);
    Brain.Screen.drawRectangle(13, 55, 302, 33);
    Brain.Screen.drawRectangle(13, 91, 302, 33);
    Brain.Screen.drawRectangle(13, 127, 302, 33);
    Brain.Screen.drawRectangle(13, 163, 302, 33);
    Brain.Screen.setFillColor(green);
    Brain.Screen.setPenColor(white);
    Brain.Screen.printAt(13,39, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(13,75, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(13,111, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(13,147, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(13,183, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    if (Brain.Screen.pressing()){
      if (Brain.Screen.xPosition() > 358){
        if (Brain.Screen.yPosition() >27){
          if(Brain.Screen.yPosition() < 214){
            Start_Screen(); // Close
            ScreenPage = 0;
          }
        }
      }
    }
    task::sleep(50);
  }
}
bool Screentoggle = false;
void BrainClickedIndicator(){
  if (Brain.Screen.pressing()){
    if (!(Screentoggle)){
      Screentoggle = true;}
    else if (Screentoggle){
      Screentoggle = false;}
    while (Controller1.ButtonLeft.pressing()){
      wait(1, msec);}}
    if (Screentoggle){}
    else if (!(Screentoggle)){
      //Click Start here
      if (ScreenPage == 0){
        if (Brain.Screen.yPosition() > 180){
          if (Brain.Screen.yPosition() < 217){
            if (Brain.Screen.xPosition() > 37){
             if (Brain.Screen.xPosition() > 234 or auto_started){
                //Device Info
                ScreenPage = 4;
                DeviceInfoScreen();
                }
              else{
                AutonomousSelection(); // autonomous selection
                ScreenPage = 1;
              }
            }
          }
        }
      }
      else if (ScreenPage == 1) {
        if (Brain.Screen.xPosition() > 358){
          if (Brain.Screen.yPosition() >27){
            if (Brain.Screen.yPosition() < 62){
              //No Auton
              ScreenPage = 0;
              current_auton_selection = 0;
              Start_Screen();
              Controller1.rumble("---");
              Controller1.Screen.clearLine(1);
              Controller1.Screen.setCursor(1,1);
              Controller1.Screen.print("No Autonomous");
            }
            else if (Brain.Screen.yPosition() < 104){
              //CloseSide Auton
              CloseSide_Auto_Screen();
              ScreenPage = 2;
            }
            else if (Brain.Screen.yPosition() < 146){
              //FarSide Auton
              FarSide_Auto_Screen();
              ScreenPage = 3;
            }
            else if(Brain.Screen.yPosition() < 214){
              Start_Screen(); // Close
              ScreenPage = 0;
            }
          }
        }
      }
      else if (ScreenPage == 2) {  // CloseSide auton
        if (Brain.Screen.xPosition() > 239){
          if (Brain.Screen.xPosition() <341 ){
            if (Brain.Screen.yPosition()<117){
              ScreenPage = 0;
              current_auton_selection = 1;
              Start_Screen();
              Controller1.rumble("---");
              Controller1.Screen.clearLine(1);
              Controller1.Screen.setCursor(1,1);
              Controller1.Screen.print("CloseSide Long");
            }
            else{
              ScreenPage = 0;
              current_auton_selection = 2;
              Start_Screen();
              Controller1.rumble("---");
              Controller1.Screen.clearLine(1);
              Controller1.Screen.setCursor(1,1);
              Controller1.Screen.print("CloseSide Short");
            }
          }
          else{
            if (Brain.Screen.yPosition() >27){
              if (Brain.Screen.yPosition() < 62){
                //No Auton
                ScreenPage = 0;
                current_auton_selection = 0;
                Start_Screen();
                Controller1.rumble("---");
                Controller1.Screen.clearLine(1);
                Controller1.Screen.setCursor(1,1);
                Controller1.Screen.print("No Autonomous");
              }
              else if (Brain.Screen.yPosition() < 104){
                //CloseSide Auton
                CloseSide_Auto_Screen();
                ScreenPage = 2;
              }
              else if (Brain.Screen.yPosition() < 146){
                //FarSide Auton
                FarSide_Auto_Screen();
                ScreenPage = 3;
              }
              else if(Brain.Screen.yPosition() < 214){
                Start_Screen(); // Close
                ScreenPage = 0;
              }
            }
          }
        }
      }
      else if (ScreenPage == 3) { //  FarSide auton
      if (Brain.Screen.xPosition() > 239){
          if (Brain.Screen.xPosition() <341 ){
            if (Brain.Screen.yPosition()<117){
              ScreenPage = 0;
              current_auton_selection = 3;
              Start_Screen();
              Controller1.rumble("---");
              Controller1.Screen.clearLine(1);
              Controller1.Screen.setCursor(1,1);
              Controller1.Screen.print("FarSide Long");
            }
            else{
              ScreenPage = 0;
              current_auton_selection = 4;
              Start_Screen();
              Controller1.rumble("---");
              Controller1.Screen.clearLine(1);
              Controller1.Screen.setCursor(1,1);
              Controller1.Screen.print("FarSide Short");
            }
          }
          else{
            if (Brain.Screen.yPosition() >27){
              if (Brain.Screen.yPosition() < 62){
                //No Auton
                ScreenPage = 0;
                current_auton_selection = 0;
                Start_Screen();
                Controller1.rumble("---");
                Controller1.Screen.clearLine(1);
                Controller1.Screen.setCursor(1,1);
                Controller1.Screen.print("No Autonoous");
              }
              else if (Brain.Screen.yPosition() < 104){
                //CloseSide Auton
                CloseSide_Auto_Screen();
                ScreenPage = 2;
              }
              else if (Brain.Screen.yPosition() < 146){
                //FarSide Auton
                FarSide_Auto_Screen();
                ScreenPage = 3;
              }
              else if(Brain.Screen.yPosition() < 214){
                Start_Screen(); // Close
                ScreenPage = 0;
              }
            }
          }
        }
      }
    }
}

      //Click Stop Here

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  default_constants();
  Start_Screen();
  ScreenPage = 0;
  current_auton_selection = 0;
  Controller1.Screen.setCursor(1,1);
  Controller1.Screen.print("No Autonomous");

  while(auto_started == false){ 
    BrainClickedIndicator();
    task::sleep(500);
  }
}

void autonomous(void) {
  auto_started = true;
  switch(current_auton_selection){  
    case 0:
      Skill_Auton();
      //No Autonomous
      break;        
    case 1:         
      CloseSide_Long_Auton();
      break;
    case 2:
      CloseSide_Short_Auton();
      break;
    case 3:
      FarSide_Long_Auton();
      break;
    case 4:
      FarSide_Short_Auton();
      break;
    case 5:
      Skill_Auton();
      break;
    case 6:
      
      break;
    case 7:

      break;
 }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  We modify the code to add  own robot specific commands here.             */
/*---------------------------------------------------------------------------*/

//Wings
bool toggleLauncher = false;
bool toggleLeftFrontWing = false;
bool toggleRightFrontWing = false;
bool toggleLeftBackWings = false;
bool toggleRightBackWings = false;
bool toggleIntakeHolder = false;
bool tempCheck = false;
bool toggleTempCheck = false;
int avgDriveTrainTemp = 0;

int LeftM1Temp = LeftM1.temperature(percentUnits::pct);
int LeftM2Temp = LeftM2.temperature(percentUnits::pct);
int LeftM3Temp = LeftM3.temperature(percentUnits::pct);
int RightM1Temp = LeftM1.temperature(percentUnits::pct);
int RightM2Temp = LeftM2.temperature(percentUnits::pct);
int RightM3Temp = LeftM3.temperature(percentUnits::pct);
int a = 10;

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.

    //wings
    if (Controller1.ButtonLeft.pressing()){
      if (!(toggleLeftFrontWing)){
        toggleLeftFrontWing = true;}
      else if (toggleLeftFrontWing){
        toggleLeftFrontWing = false;}
      while (Controller1.ButtonLeft.pressing()){
      wait(1, msec);}}
      if (toggleLeftFrontWing){
        leftFrontWing.set(true);}
      else if (!(toggleLeftFrontWing)){  
        leftFrontWing.set(false);}
    
    if (Controller1.ButtonRight.pressing()){
      if (!(toggleRightFrontWing)){
        toggleRightFrontWing = true;}
      else if (toggleRightFrontWing){
        toggleRightFrontWing = false;}
      while (Controller1.ButtonRight.pressing()){
      wait(1, msec);}}
      if (toggleRightFrontWing){
        rightFrontWing.set(true);}
      else if (!(toggleRightFrontWing)){
        rightFrontWing.set(false);}
    
    if (Controller1.ButtonY.pressing()){
      if (!(toggleLeftBackWings)){
        toggleLeftBackWings = true;}
      else if (toggleLeftBackWings){
        toggleLeftBackWings = false;}
      while (Controller1.ButtonY.pressing()){
      wait(1, msec);}}
      if (toggleLeftBackWings){
        leftBackWing.set(true);}
      else if (!(toggleLeftBackWings)){
        leftBackWing.set(false);}

    if (Controller1.ButtonA.pressing()){
      if (!(toggleRightBackWings)){
        toggleRightBackWings = true;}
      else if (toggleRightBackWings){
        toggleRightBackWings = false;}
      while (Controller1.ButtonA.pressing()){
      wait(1, msec);}}
      if (toggleRightBackWings){
        rightBackWing.set(true);}
      else if (!(toggleRightBackWings)){
        rightBackWing.set(false);}

    //inake
    if (Controller1.ButtonX.pressing()){
      if (!(toggleIntakeHolder)){
        toggleIntakeHolder = true;}
      else if (toggleIntakeHolder){
        toggleIntakeHolder = false;}
      while (Controller1.ButtonX.pressing()){
      wait(1, msec);}}
      if (toggleIntakeHolder){
        IntakeHolder.set(true);}
      else if (!(toggleIntakeHolder)){
        IntakeHolder.set(false);}

    if (Controller1.ButtonL1.pressing()){
      intakeMotor.setVelocity(100, percent);
      intakeMotor.setMaxTorque(100,percent);
      intakeMotor.setBrake(coast);
      intakeMotor.spin(forward);
    }
    else if (Controller1.ButtonL2.pressing()) {
      intakeMotor.setVelocity(100, percent);
      intakeMotor.setMaxTorque(100,percent);
      intakeMotor.setBrake(coast);
      intakeMotor.spin(reverse);
    }
    else {
      intakeMotor.stop();
    }


    //Launcher
    if (Controller1.ButtonB.pressing()){
      if (!(toggleLauncher)){
        toggleLauncher = true;}
      else if (toggleLauncher){
        toggleLauncher = false;}
      while (Controller1.ButtonB.pressing()){
      wait(1, msec);}}
      if (toggleLauncher){
        puncherMotor.setVelocity(100, percent);
        puncherMotor.setMaxTorque(100, percent);
        puncherMotor.spin(forward);}
      else if (!(toggleLauncher)){
        puncherMotor.stop();}
    //test
    if (Controller1.ButtonUp.pressing()){
      LeftM1Temp = LeftM1.temperature(percentUnits::pct);
      LeftM2Temp = LeftM2.temperature(percentUnits::pct);
      LeftM3Temp = LeftM3.temperature(percentUnits::pct);
      RightM1Temp = LeftM1.temperature(percentUnits::pct);
      RightM2Temp = LeftM2.temperature(percentUnits::pct);
      RightM3Temp = LeftM3.temperature(percentUnits::pct);
      avgDriveTrainTemp = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
      Controller1.Screen.clearLine(1);
      Controller1.Screen.setCursor(1,1);
      Controller1.Screen.print("AvgTemp:");
      Controller1.Screen.setCursor(1,10);
      Controller1.Screen.print(avgDriveTrainTemp);
    }
    //Replace this line with chassis.control_tank(); for tank drive 
    //or chassis.control_solonomic(); for holo drive.
    chassis.control_arcade();

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
    
  }
}

//
// Main will set up the competition functions and callbacks.
//
bool CompetitionStarted = false;
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  chassis.set_coordinates(0, 0, 0);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
