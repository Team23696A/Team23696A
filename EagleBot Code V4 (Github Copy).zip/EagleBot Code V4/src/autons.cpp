#include "vex.h"

void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(10, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 700);
  chassis.set_turn_exit_conditions(1, 200, 700);
  chassis.set_swing_exit_conditions(1, 200, 700);
}

void FarSide_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(12, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 600);
  chassis.set_turn_exit_conditions(1, 200, 600);
  chassis.set_swing_exit_conditions(1, 200, 600);
}

void CloseSide_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(12, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 500);
  chassis.set_turn_exit_conditions(1, 200, 500);
  chassis.set_swing_exit_conditions(1, 200, 500);
}



void No_Auton(){
  chassis.drive_max_voltage = 12;
  default_constants();
  chassis.set_coordinates(0, 0, 25);
  IntakeHolder.set(true);
  wait(0.2, sec);
}

void CloseSide_Short_Auton(){
  chassis.drive_max_voltage = 12;
  default_constants();
  chassis.set_coordinates(0, 0, 25);
  IntakeHolder.set(true);
  wait(0.2, sec);
  chassis.drive_distance(-35);
  chassis.drive_distance(30);
}

void CloseSide_Long_Auton(){
  chassis.drive_max_voltage = 12;
  FarSide_constants();
  chassis.set_coordinates(0, 0, 0);
  leftFrontWing.set(true);
  IntakeHolder.set(true);
  wait(0.8, sec);
  leftFrontWing.set(false);
  chassis.drive_distance(20);
  chassis.turn_to_angle(10);
  intakeMotor.setMaxTorque(100, percent);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  chassis.drive_distance(31);
  wait(0.5, sec);
  intakeMotor.setVelocity(20, percent);
  chassis.turn_to_angle(90);
  leftFrontWing.set(true);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  chassis.drive_distance(27);
  wait(0.5, sec);
  chassis.drive_distance(-10);
  leftFrontWing.set(false);
  intakeMotor.setVelocity(20, percent);
  chassis.turn_to_angle(220);
  chassis.drive_distance(40);
  chassis.drive_distance(20);
  chassis.right_swing_to_angle(140);
  chassis.drive_distance(-23);
  chassis.right_swing_to_angle(180);
  chassis.drive_distance(5);
  chassis.drive_distance(-17);
  chassis.drive_distance(10);
  chassis.drive_distance(-2);
  chassis.right_swing_to_angle(138);
  rightFrontWing.set(true);
  chassis.drive_distance(20);
  chassis.turn_to_angle(90);
  rightFrontWing.set(false);
  chassis.turn_to_angle(110);
  chassis.drive_distance(20);
  chassis.turn_to_angle(90);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  chassis.drive_distance(22);
}
void FarSide_Short_Auton(){
  chassis.drive_max_voltage = 12;
  default_constants(); 
  chassis.set_coordinates(0, 0, 0);
  IntakeHolder.set(true);
  intakeMotor.setMaxTorque(100, percent);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  chassis.drive_distance(37);
  chassis.turn_to_angle(80);
  intakeMotor.spin(reverse);
  wait(0.3,sec);
  chassis.drive_distance(-8);
  intakeMotor.setVelocity(20, percent);
  intakeMotor.spin(forward);
  chassis.turn_to_angle(260);
  intakeMotor.setVelocity(100, percent);
  chassis.drive_distance(18);
  wait(0.2, sec);
  chassis.drive_distance(-15);
  chassis.turn_to_angle(80);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  wait(0.2, sec);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(330);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  chassis.drive_distance(15);
  wait(0.2, sec);
  chassis.turn_to_angle(90);
  intakeMotor.spin(reverse);
  leftFrontWing.set(true);
  rightFrontWing.set(true);
  chassis.drive_distance(30);
  chassis.drive_distance(-25);
  chassis.drive_distance(29);
  leftFrontWing.set(false);
  rightFrontWing.set(false);
  wait(0.5,sec);
  chassis.drive_distance(-10);
  intakeMotor.stop();
  intakeMotor.setVelocity(30, percent);
  chassis.turn_to_angle(43);
  chassis.drive_distance(-43);
  rightBackWing.set(true);
  chassis.right_swing_to_angle(110);
}

void FarSide_Long_Auton(){
  chassis.drive_max_voltage = 14;
  FarSide_constants();
  chassis.set_coordinates(0, 0, 0);
  IntakeHolder.set(true);
  intakeMotor.setMaxTorque(100, percent);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  wait(0.6, sec);
  intakeMotor.setVelocity(30, percent);
  chassis.drive_distance(-32.5);
  chassis.left_swing_to_angle(317);
  chassis.drive_distance(-9.5);
  leftBackWing.set(true);
  wait(0.3, sec);
  chassis.turn_to_angle(290);
  leftBackWing.set(false);
  chassis.left_swing_to_angle(315);
  chassis.drive_distance(-9.5);
  chassis.turn_to_angle(270);
  leftBackWing.set(true);
  chassis.drive_distance(-20);
  leftBackWing.set(false);
  chassis.drive_distance(19);
  chassis.turn_to_angle(90);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  rightFrontWing.set(true);
  wait(0.1, sec);
  chassis.drive_distance(20);
  rightFrontWing.set(false);
  chassis.drive_distance(-15);
  intakeMotor.spin(forward);
  chassis.turn_to_angle(27);
  chassis.drive_distance(33);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  chassis.drive_distance(23);
  wait(0.1, sec);
  intakeMotor.setVelocity(30, percent);
  chassis.turn_to_angle(160);
  chassis.drive_distance(20);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  chassis.drive_distance(-10);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(forward);
  chassis.turn_to_angle(48);
  chassis.drive_distance(20.5);
  chassis.turn_to_angle(180);
  intakeMotor.spin(reverse);
  leftFrontWing.set(true);
  rightFrontWing.set(true);
  chassis.drive_distance(33);
  chassis.drive_distance(-25);
  chassis.drive_distance(30);
  leftFrontWing.set(false);
  rightFrontWing.set(false);
  wait(2,sec);
  intakeMotor.stop();
}

void Skill_Auton(){
  chassis.drive_max_voltage = 12;
  default_constants(); 
  chassis.set_coordinates(0, 0, 0);
  chassis.drive_max_voltage = 12;
  default_constants();
  IntakeHolder.set(true);
  leftFrontWing.set(true);
  wait(0.5, sec);
  chassis.turn_to_angle(315);
  chassis.drive_distance(22);
  chassis.left_swing_to_angle(0);
  intakeMotor.setVelocity(100, percent);
  intakeMotor.spin(reverse);
  leftFrontWing.set(false);
  wait(0.5, sec);
  chassis.drive_distance(-5);
  chassis.turn_to_angle(180);
  intakeMotor.stop();
  chassis.drive_distance(-20);
  chassis.drive_distance(17);
  chassis.turn_to_angle(70);
  rightBackWing.set(true);
  chassis.drive_distance(-5);
  puncherMotor.setMaxTorque(100, percent);
  puncherMotor.setVelocity(100, percent);
  puncherMotor.spin(forward);
  wait(32, sec); //decress the time for testing.
  puncherMotor.stop();
  rightBackWing.set(false);
  chassis.drive_distance(5);
  chassis.turn_to_angle(68);
  chassis.drive_distance(48);
  intakeMotor.spin(forward);
  chassis.drive_distance(15);
  wait(0.2, sec);
  chassis.turn_to_angle(15);
  intakeMotor.spin(reverse);
  leftFrontWing.set(true);
  chassis.drive_distance(30);
  chassis.turn_to_angle(0);
  chassis.drive_distance(40);
  chassis.drive_distance(-5);
  chassis.drive_distance(10);
  chassis.drive_distance(-5);
  chassis.turn_to_angle(300);
  chassis.drive_distance(22);
  chassis.left_swing_to_angle(0);
  chassis.drive_distance(20);
  leftFrontWing.set(false);
  chassis.turn_to_angle(70);
  rightFrontWing.set(true);
  chassis.drive_distance(15);
  chassis.turn_to_angle(90);
  chassis.drive_distance(40);
  chassis.drive_distance(40);
  chassis.drive_distance(-4);
  chassis.turn_to_angle(90);
  chassis.turn_to_angle(135);
  chassis.drive_distance(30);
  chassis.turn_to_angle(180);
  chassis.drive_distance(15.5);
  chassis.drive_distance(-11);
  rightFrontWing.set(false);
  chassis.turn_to_angle(250);
  intakeMotor.setVelocity(20, percent);
  intakeMotor.spin(forward);
  chassis.drive_distance(20);
  chassis.drive_distance(30);
  chassis.turn_to_angle(320);
  rightBackWing.set(true);
  leftBackWing.set(true);
  wait(0.5, sec);
  chassis.drive_distance(-30);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-15);
  chassis.turn_to_angle(320);
  chassis.drive_distance(-20);
  rightBackWing.set(false);
  leftBackWing.set(false);
  chassis.drive_distance(15);
  chassis.turn_to_angle(230);
  chassis.drive_distance(35);
  chassis.turn_to_angle(280);
  leftBackWing.set(true);
  rightBackWing.set(true);
  wait(0.5, sec);
  chassis.drive_distance(-20);
  chassis.turn_to_angle(270);
  chassis.drive_distance(-30);
  leftBackWing.set(false);
  rightBackWing.set(false);
  chassis.drive_distance(5);
} 