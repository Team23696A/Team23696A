/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Richard Wang (1698V)                                      */
/*    Created:      July 9, 2023                                              */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

#include "vex.h"
#include "motor-control.h"
#include "math.h"
#include "autonomous.h"

using namespace vex;

// A global instance of competition
competition Competition;

// controller_1 input variables (snake_case)
int ch1, ch2, ch3, ch4;
bool l1, l2, r1, r2;
bool button_a, button_b, button_x, button_y;
bool button_up_arrow, button_down_arrow, button_left_arrow, button_right_arrow;
int chassis_flag = 0;

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  
  // Calibrate inertial sensor
  inertial_sensor.calibrate();

  // Wait for the Inertial Sensor to calibrate
  while (inertial_sensor.isCalibrating()) {
    wait(10, msec);
  }

  double current_heading = inertial_sensor.heading();
  Brain.Screen.print(current_heading);
  
  resetChassis();
  if(using_tracking_wheels) {
    thread odom = thread(trackOdomWheel);
  } else {
    thread odom = thread(trackOdom);
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*                                                                           */
/*-------------------------------
--------------------------------------------*/

void autonomous(void) {
  int auton_selected = 3;
  switch(auton_selected) {
    case 1:
      exampleAuton();
      break;
    case 2:
      exampleAuton2();
      break;  
    case 3:
      redGoalRush();
      break;
    case 4:
      break; 
    case 5:
      break;
    case 6:
      break;
    case 7:
      break;
    case 8:
      break;
    case 9:
      break;
  }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/
//Variables used in Driver Control 
int LeftM1Temp = 0;
int LeftM2Temp = 0;
int LeftM3Temp = 0;
int RightM1Temp = 0;
int RightM2Temp = 0;
int RightM3Temp = 0;
bool ToggleTempDisplay = false;
int a=0;
//Average Temp Calculations

void displayAvgTemp(){
  if (button_a == true){
      LeftM1Temp = left_chassis1.temperature(percentUnits::pct);
      LeftM2Temp = left_chassis2.temperature(percentUnits::pct);
      LeftM3Temp = left_chassis3.temperature(percentUnits::pct);
      RightM1Temp = right_chassis1.temperature(percentUnits::pct);
      RightM2Temp = right_chassis2.temperature(percentUnits::pct);
      RightM3Temp = right_chassis3.temperature(percentUnits::pct);
      a = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
      controller_1.Screen.clearLine(1);
      controller_1.Screen.setCursor(1,1);
      controller_1.Screen.print("AvgTemp:");
      controller_1.Screen.setCursor(1,10);
      controller_1.Screen.print(a);
    }
}
//intake toggles




void usercontrol(void) {
  stopChassis(coast);
  heading_correction = false;
  while (true) {
    // [-100, 100] for controller stick axis values
    ch1 = controller_1.Axis1.value();
    ch2 = controller_1.Axis2.value();
    ch3 = controller_1.Axis3.value();
    ch4 = controller_1.Axis4.value();

    // true/false for controller button presses
    l1 = controller_1.ButtonL1.pressing();
    l2 = controller_1.ButtonL2.pressing();
    r1 = controller_1.ButtonR1.pressing();
    r2 = controller_1.ButtonR2.pressing();
    button_a = controller_1.ButtonA.pressing();
    button_b = controller_1.ButtonB.pressing();
    button_x = controller_1.ButtonX.pressing();
    button_y = controller_1.ButtonY.pressing();
    button_up_arrow = controller_1.ButtonUp.pressing();
    button_down_arrow = controller_1.ButtonDown.pressing();
    button_left_arrow = controller_1.ButtonLeft.pressing();
    button_right_arrow = controller_1.ButtonRight.pressing();

    // default tank drive or replace it with your preferred driver code here: 
    driveChassis(ch3 * 0.12, ch2 * 0.12);
    
    //Controls
    //Intake Control (Forward Toggle)
    if (button_x == true){
    if (!(toggleIntakeF)){
        toggleIntakeF = true;}
      else if (toggleIntakeF){
        toggleIntakeF = false;}
      while (button_y == true){
      wait(1, msec);}
    }
      if (toggleIntakeF){
        intake_motor.setVelocity(100, percent);
        intake_motor.setMaxTorque(100, percent);
        intake_motor.spin(forward);}
      else if (!(toggleIntakeF)){
        intake_motor.stop();
      }

    //Intake Control (Reverse Toggle)
    if (button_up_arrow == true){
      if (!(toggleIntakeR)){
        toggleIntakeR = true;}
      else if (toggleIntakeR){
        toggleIntakeR = false;}
      while (button_up_arrow == true){
      wait(1, msec);}
    }
      if (toggleIntakeR){
        intake_motor.setVelocity(100, percent);
        intake_motor.setMaxTorque(100, percent);
        intake_motor.spin(reverse);}
      else if (!(toggleIntakeR)){
        intake_motor.stop();
      }

      //Intake Control (Forward Manual)
    if(button_y == true){
      intake_motor.setVelocity(100, percent);
      intake_motor.setMaxTorque(100,percent);
      intake_motor.setBrake(coast);
      intake_motor.spin(forward);
    }
    
    //Intake Control (Reverse Manual)
    else if(button_right_arrow == true){
      intake_motor.setVelocity(100, percent);
      intake_motor.setMaxTorque(100,percent);
      intake_motor.setBrake(coast);
      intake_motor.spin(reverse);
    }

    //Avg Temp display
    displayAvgTemp();

    wait(10, msec); 
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
