void exampleAuton();
void exampleAuton2();
void redGoalRush();