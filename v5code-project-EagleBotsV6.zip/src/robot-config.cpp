#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
controller Controller1 = controller(primary);
inertial InertialSensor = inertial(PORT16);
motor RightM1 = motor(PORT17, ratio6_1, false);
motor RightM2 = motor(PORT18, ratio6_1, false);
motor RightM3 = motor(PORT19, ratio6_1, true);
motor LeftM1 = motor(PORT11, ratio6_1, true);
motor LeftM2 = motor(PORT12, ratio6_1, false);
motor LeftM3 = motor(PORT13, ratio6_1, true);
rotation SideTrack = rotation(PORT14, false);
rotation ForwardTrack = rotation(PORT15, false);
motor Intake1 = motor(PORT8, ratio6_1, false);
motor Intake2 = motor(PORT9, ratio18_1, false);
motor Intake3 = motor(PORT10, ratio18_1, false);
digital_out LilWill = digital_out(Brain.ThreeWirePort.A);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}