#include "vex.h"
#include "globals.h"
void calculateAverageTemperature(void){
          LeftM1Temp = LeftM1.temperature(celsius);
        LeftM2Temp = LeftM2.temperature(celsius);
        LeftM3Temp = LeftM3.temperature(celsius);
        RightM1Temp = RightM1.temperature(celsius);
        RightM2Temp = RightM2.temperature(celsius);
        RightM3Temp = RightM3.temperature(celsius);
       //IntakeTemp = intakeMotor.temperature(celsius);
        avgDriveTrainTemp = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
        
}
void displayAvgTemp(){
  if (Controller1.ButtonUp.pressing()){
      LeftM1Temp = LeftM1.temperature(percentUnits::pct);
      LeftM2Temp = LeftM2.temperature(percentUnits::pct);
      LeftM3Temp = LeftM3.temperature(percentUnits::pct);
      RightM1Temp = LeftM1.temperature(percentUnits::pct);
      RightM2Temp = LeftM2.temperature(percentUnits::pct);
      RightM3Temp = LeftM3.temperature(percentUnits::pct);
      avgDriveTrainTemp = (LeftM1Temp+LeftM2Temp+LeftM3Temp+RightM1Temp+RightM2Temp+RightM3Temp)/6;
      Controller1.Screen.clearLine(1);
      Controller1.Screen.setCursor(1,1);
      Controller1.Screen.print("AvgTemp:");
      Controller1.Screen.setCursor(1,10);
      Controller1.Screen.print(avgDriveTrainTemp);
    }
}