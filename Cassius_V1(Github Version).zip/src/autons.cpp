#include "vex.h"

void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(10, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 700);
  chassis.set_turn_exit_conditions(1, 200, 700);
  chassis.set_swing_exit_conditions(1, 200, 700);
}

void FarSide_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(12, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 600);
  chassis.set_turn_exit_conditions(1, 200, 600);
  chassis.set_swing_exit_conditions(1, 200, 600);
}

void CloseSide_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 1.5, 0, 10, 0);
  chassis.set_heading_constants(12, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1.5, 200, 500);
  chassis.set_turn_exit_conditions(1, 200, 500);
  chassis.set_swing_exit_conditions(1, 200, 500);
}

//all autons must have distance 1.13 inches less or more than the actual distance driven due to inertial position relative to the center of the robot
// if the robot is going to move backwards, add 1.13 inches to the desired distance due the the reason given above
//if you are moving forwards, subtract 1.13 inches
//add 0.75 inches for clamping
void No_Auton(){
  chassis.turn_to_angle(90);
}

void Red_RHS(){
  /*
  intakeMotor.setVelocity(100, percent);
  Mogo.set(false);
  intakeMotor.spin(forward,100,percent);
  chassis.drive_distance(33.25);
  Mogo.set(true);
  chassis.turn_to_angle(90);
  chassis.drive_distance(20.25);
  chassis.turn_to_angle(180);
  chassis.drive_distance(25.25);
  */
}

void Red_LHS(){
  /*
  intakeMotor.setVelocity(100, percent);
  Mogo.set(false);
  intakeMotor.spin(forward,100,percent);
  chassis.drive_distance(35.25);
  chassis.drive_distance(0.75);
  Drivetrain.driveFor(forward, 0.25, inches);
  Mogo.set(true);
  Drivetrain.turnFor(right,62.5, degrees);
  SmartDrivetrain.driveFor(forward, 23.25 ,inches);
  SmartDrivetrain.turnFor(right,11, degrees);
  SmartDrivetrain.driveFor(forward,13.25,inches);
  SmartDrivetrain.driveFor(reverse,13.25,inches);
  SmartDrivetrain.turnFor(left,40,degrees);
  SmartDrivetrain.driveFor(forward,13.25,inches);
  SmartDrivetrain.driveFor(reverse,13.25,inches);
  SmartDrivetrain.turnFor(right,115,degrees);
  SmartDrivetrain.driveFor(forward,43.25,inches);
  */
}

void Blue_LHS(){
  /*
  Intake.setVelocity(100, percent);
  Mogo.set(false);
  Drivetrain.setDriveVelocity(30, percent);
  Intake.spin(forward,100,percent);
  Drivetrain.driveFor(reverse, 34.25, inches);
  Mogo.set(true);
  Drivetrain.turnFor(left,90, degrees);
  Drivetrain.driveFor(forward, 20.25 ,inches);
  Drivetrain.turnFor(left,180, degrees);
  Drivetrain.setDriveVelocity(100,  percent);
  Drivetrain.driveFor(forward, 25.25 ,inches);
  */
}

void Blue_RHS(){
  /*
  Intake.setVelocity(100, percent);
  Intake.spin(forward);
  Mogo.set(false);
  Drivetrain.setDriveVelocity(30, percent);
  Intake.spin(forward,100,percent);
  Drivetrain.driveFor(reverse, 31.25, inches);
  Mogo.set(true);
  Drivetrain.turnFor(right,90, degrees);
  Drivetrain.driveFor(forward, 21.25 ,inches);
  Drivetrain.turnFor(right,115, degrees);
  Drivetrain.driveFor(forward,13.25,inches);
  Drivetrain.driveFor(reverse,13.25,inches);
  Drivetrain.turnFor(left,50,degrees);
  Drivetrain.driveFor(forward,13.25,inches);
  Drivetrain.driveFor(reverse,13.25,inches);
  Drivetrain.turnFor(right,115,degrees);
  Drivetrain.driveFor(forward,43.25,inches);
  */
} 


void RedRush(){

} 
void BlueRush(){

} 
void Skill_Auton(){
  /*
  //LadybrownFlip();
  Drivetrain.setDriveVelocity(100, percent);
  Intake.spin(forward,100,percent);
  Drivetrain.driveFor(forward,10.83,inches);
  Drivetrain.turnFor(-90, degrees);
  Drivetrain.driveFor(reverse,25.13,inches);
  Drivetrain.turnFor(0, degrees);
  */
}