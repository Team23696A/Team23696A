#include "vex.h"

void default_constants() {
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form of (settle_error, settle_time,
  // timeout).
  chassis.set_drive_exit_conditions(1.5, 300, 3000);
  chassis.set_turn_exit_conditions(1, 300, 3000);
  chassis.set_swing_exit_conditions(1, 300, 3000);
}

void Elim_constants() {
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(10, 1.5, 0, 10, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .4, .03, 3, 15);
  chassis.set_swing_constants(12, .3, .001, 2, 15);

  // Each exit condition set is in the form of (settle_error, settle_time,
  // timeout).
  chassis.set_drive_exit_conditions(1.5, 150, 1000);
  chassis.set_turn_exit_conditions(1, 150, 1000);
  chassis.set_swing_exit_conditions(1, 200, 1000);
}

// void CloseSide_constants(){
//   // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
//   chassis.set_drive_constants(12, 1.5, 0, 10, 0);
//   chassis.set_heading_constants(12, .4, 0, 1, 0);
//   chassis.set_turn_constants(12, .4, .03, 3, 15);
//   chassis.set_swing_constants(12, .3, .001, 2, 15);

//   // Each exit condition set is in the form (settle_error, settle_time,
//   timeout). chassis.set_drive_exit_conditions(1.5, 200, 500);
//   chassis.set_turn_exit_conditions(1, 200, 500);
//   chassis.set_swing_exit_conditions(1, 200, 500);
// }

//.set_coordinates works as X coordinate, Y coordinate, orientation (In degrees,
//360 degree format)
void TestDrive() {
  // chassis.drive_max_voltage = 12;
  // default_constants();
  // chassis.set_coordinates(0, 0, 25);
  // chassis.drive_distance(100);
  // chassis.drive_distance(-100);
  // chassis.turn_to_angle(90);
  // chassis.drive_distance(100);
  // chassis.drive_distance(-100);
  // chassis.turn_to_angle(180);
  // chassis.drive_distance(100);
  // chassis.drive_distance(-100);
  // chassis.turn_to_angle(270);
  // chassis.drive_distance(100);
  // chassis.drive_distance(-100);
  // chassis.turn_to_angle(0);
  // chassis.drive_distance(100);
  // chassis.drive_distance(-100);
  // chassis.set_coordinates(0, 0, 25);
}

void No_Auton() {
  chassis.drive_max_voltage = 12;
  default_constants();
  chassis.set_coordinates(0, 0, 25);
  wait(0.2, sec);
  chassis.drive_distance(5);
}

void Red_RHS_S2() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  // chassis.drive_distance(5);
  chassis.drive_distance(-38.5);
  LilWill.set(true);
  chassis.turn_to_angle(-93);
  chassis.drive_distance(14.3);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-21);
  chassis.turn_to_angle(-86);
  chassis.drive_distance(-10);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

void Red_LHS_S2() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  // chassis.drive_distance(5);
  chassis.drive_distance(-38.5);
  LilWill.set(true);
  chassis.turn_to_angle(93);
  chassis.drive_distance(14.3);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-21);
  chassis.turn_to_angle(86);
  chassis.drive_distance(-10);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

// void Red_LHS(){
//   Elim_constants();
//   Intake1.setVelocity(100, pct);
//   Intake2.setVelocity(100, pct);
//   Intake3.setVelocity(100, pct);
//   SW.set(true);
//   chassis.turn_to_angle(7.5);
//   Intake1.spin(forward);
//   Intake2.spin(reverse);
//   Intake3.spin(forward);
//   chassis.drive_distance(20);
//   chassis.drive_max_voltage=6;
//   chassis.drive_distance(4);
//   chassis.drive_distance(2);
//   chassis.drive_max_voltage=9;
//   chassis.drive_distance(2.5);
//   Intake1.stop();
//   Intake2.stop();
//   Intake3.stop();
//   chassis.turn_to_angle(-101.5);
//   chassis.drive_distance(-16);
//   //chassis.turn_to_angle(-107);
//   SW.set(false);
//   Intake1.setVelocity(70,pct);
//   Intake2.setVelocity(70,pct);
//   Intake3.setVelocity(70,pct);
//   Intake1.spin(reverse);
//   Intake2.spin(forward);
//   Intake3.spin(reverse);
//   wait(0.2,sec);
//   Intake1.spin(forward);
//   Intake2.spin(reverse);
//   Intake3.spin(reverse);
//   wait(1,sec);
//   Intake1.stop();
//   Intake2.stop();
//   Intake3.stop();
//   chassis.drive_distance(50);
//   chassis.turn_to_angle(-146);
//   LilWill.set(true);
//   SW.set(true);
//   wait(0.2,sec);
//   Intake1.setVelocity(100, pct);
//   Intake2.setVelocity(100, pct);
//   Intake3.setVelocity(100, pct);
//   Intake1.spin(forward);
//   Intake2.spin(reverse);
//   Intake3.spin(forward);
//   chassis.drive_max_voltage=12;
//   chassis.drive_distance(12.8);
//   chassis.drive_distance(5.25);
//   wait(0.2,sec);
//   chassis.turn_to_angle(-144);
//   chassis.drive_max_voltage=9;
//   chassis.drive_distance(-20);
//   chassis.turn_to_angle(-146);
//   chassis.drive_distance(-15);
//   LilWill.set(false);
//   SW.set(false);
//   Intake1.spin(reverse);
//   Intake2.spin(forward);
//   Intake3.spin(reverse);
//   wait(0.2,sec);
//   Intake1.spin(forward);
//   Intake2.spin(reverse);
//   Intake3.spin(forward);
//   wait(0.2,sec);
//   Intake1.spin(forward);
//   Intake2.spin(reverse);
//   Intake3.spin(forward);
// }

void Red_Elim() {
  Elim_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  chassis.turn_to_angle(10);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  chassis.drive_distance(18);
  LilWill.set(true);
  chassis.drive_max_voltage = 6;
  chassis.drive_distance(4);
  chassis.turn_to_angle(5);
  chassis.drive_distance(2);
  chassis.drive_max_voltage = 9;
  chassis.drive_distance(4);
  chassis.drive_distance(-1);
  //  Intake1.stop();
  //  Intake2.stop();
  //  Intake3.stop();
  chassis.turn_to_angle(-101.5);
  chassis.drive_distance(-16);
  // chassis.turn_to_angle(-107);
  SW.set(false);
  Intake1.setVelocity(70, pct);
  Intake2.setVelocity(70, pct);
  Intake3.setVelocity(70, pct);
  chassis.drive_distance(0.25);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.2, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(reverse);
  wait(1, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
  chassis.drive_distance(50);
  chassis.turn_to_angle(-146);
  LilWill.set(true);
  SW.set(true);
  wait(0.2, sec);
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  chassis.drive_max_voltage = 12;
  chassis.drive_distance(8.3);
  chassis.drive_distance(4.25);
  wait(0.2, sec);
  chassis.turn_to_angle(-144);
  chassis.drive_max_voltage = 9;
  chassis.drive_distance(-20);
  chassis.turn_to_angle(-148);
  chassis.drive_distance(-15);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.2, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(0.2, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
}

void Blue_LHS() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  chassis.drive_distance(5);
  chassis.drive_distance(-54.5);
  LilWill.set(true);
  chassis.turn_to_angle(91);
  chassis.drive_distance(14.75);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-31);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

void Blue_RHS() {
  // default_constants();
  // Intake1.setVelocity(100, pct);
  // Intake2.setVelocity(100, pct);
  // Intake3.setVelocity(100, pct);
  // SW.set(true);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // chassis.drive_distance(5);
  // chassis.drive_distance(-54.5);
  // LilWill.set(true);
  // chassis.turn_to_angle(-91);
  // chassis.drive_distance(14.75);
  // wait(0.2,sec);
  // chassis.drive_distance(0.25);
  // wait(1.6,sec);
  // chassis.drive_distance(-31);
  // LilWill.set(false);
  // SW.set(false);
  // Intake1.spin(reverse);
  // Intake2.spin(forward);
  // Intake3.spin(reverse);
  // wait(0.1,sec);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // wait(2,sec);
  // Intake1.stop();
  // Intake2.stop();
  // Intake3.stop();
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  chassis.drive_max_voltage = 9;
  chassis.drive_distance(5);
  chassis.drive_distance(-54.5);
  LilWill.set(true);
  chassis.turn_to_angle(-91);
  chassis.drive_distance(14.75);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-31);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

void Blue_RHS_S2() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  // chassis.drive_distance(5);
  chassis.drive_distance(-38.5);
  LilWill.set(true);
  chassis.turn_to_angle(-93);
  chassis.drive_distance(14.3);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-21);
  chassis.turn_to_angle(-86);
  chassis.drive_distance(-10);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

void Blue_LHS_S2() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  // chassis.drive_distance(5);
  chassis.drive_distance(-38.5);
  LilWill.set(true);
  chassis.turn_to_angle(93);
  chassis.drive_distance(14.3);
  wait(0.2, sec);
  chassis.drive_distance(0.25);
  wait(1.6, sec);
  chassis.drive_distance(-21);
  chassis.turn_to_angle(86);
  chassis.drive_distance(-10);
  LilWill.set(false);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(0.1, sec);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(2, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
}

void Blue_Elim() {
  Elim_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  chassis.turn_to_angle(-5);
  Intake1.spin(forward);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  chassis.drive_distance(40);
  LilWill.set(true);
  chassis.drive_distance(5);
  
}

void RedAWP() {
  default_constants();
  Intake1.spin(forward);
  chassis.drive_distance(5);
  chassis.drive_distance(-55);
  chassis.turn_to_angle(90);
  chassis.drive_distance(6.3);
  wait(1.25, sec);
  chassis.drive_distance(-23);
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  Intake1.spin(reverse);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(0.05, sec);
  Intake1.spin(forward);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(2, sec);
}
void BlueAWP() {
  default_constants();
  Intake1.setVelocity(100, pct);
  Intake2.setVelocity(100, pct);
  Intake3.setVelocity(100, pct);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  chassis.drive_distance(5);
  chassis.drive_distance(-55);
  chassis.turn_to_angle(-90);
  chassis.drive_distance(-18);
  SW.set(false);
  Intake1.spin(reverse);
  Intake2.spin(reverse);
  Intake3.spin(forward);
  wait(0.05, sec);
  Intake1.spin(forward);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  wait(1.75, sec);
  Intake1.stop();
  Intake2.stop();
  Intake3.stop();
  chassis.turn_to_angle(112.25);
  chassis.drive_distance(24.23);
  LilWill.set(true);
  SW.set(true);
  Intake1.spin(forward);
  Intake2.spin(forward);
  Intake3.spin(reverse);
  chassis.drive_distance(0.5);
}
void Skill_Auton() {
  LilWill.set(true);
  chassis.drive_distance(-3.5);
  chassis.drive_distance(45);
  // Elim_constants();
  // Intake1.setVelocity(100, pct);
  // Intake2.setVelocity(100, pct);
  // Intake3.setVelocity(100, pct);
  // SW.set(true);
  // chassis.turn_to_angle(7.5);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // chassis.drive_distance(20);
  // chassis.drive_max_voltage=6;
  // chassis.drive_distance(4);
  // chassis.drive_distance(2);
  // chassis.drive_max_voltage=9;
  // chassis.drive_distance(2.5);
  // Intake1.stop();
  // Intake2.stop();
  // Intake3.stop();
  // chassis.turn_to_angle(-101.5);
  // chassis.drive_distance(-16);
  // //chassis.turn_to_angle(-107);
  // SW.set(false);
  // Intake1.setVelocity(70,pct);
  // Intake2.setVelocity(70,pct);
  // Intake3.setVelocity(70,pct);
  // Intake1.spin(reverse);
  // Intake2.spin(forward);
  // Intake3.spin(reverse);
  // wait(0.2,sec);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(reverse);
  // wait(1,sec);
  // Intake1.stop();
  // Intake2.stop();
  // Intake3.stop();
  // chassis.drive_distance(50);
  // chassis.turn_to_angle(-146);
  // LilWill.set(true);
  // SW.set(true);
  // wait(0.2,sec);
  // Intake1.setVelocity(100, pct);
  // Intake2.setVelocity(100, pct);
  // Intake3.setVelocity(100, pct);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // chassis.drive_max_voltage=12;
  // chassis.drive_distance(12.8);
  // chassis.drive_distance(5.25);
  // wait(0.2,sec);
  // chassis.turn_to_angle(-144);
  // chassis.drive_max_voltage=9;
  // chassis.drive_distance(-20);
  // chassis.turn_to_angle(-146);
  // chassis.drive_distance(-15);
  // LilWill.set(false);
  // SW.set(false);
  // Intake1.spin(reverse);
  // Intake2.spin(forward);
  // Intake3.spin(reverse);
  // wait(0.2,sec);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // wait(0.2,sec);
  // Intake1.spin(forward);
  // Intake2.spin(reverse);
  // Intake3.spin(forward);
  // chassis.drive_distance(15);
  // chassis.turn_to_angle(97);
  // chassis.drive_distance(60);
  // chassis.turn_to_angle(-173);
  // chassis.drive_distance(12);
  // chassis.turn_to_angle(-97);
  // chassis.drive_distance(5);
  // LilWill.set(true);
  // chassis.drive_distance(-3.5);
  // chassis.drive_distance(45);
}