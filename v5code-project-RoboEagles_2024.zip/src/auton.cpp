#include "vex.h"
//all autons must have distance 1.13 inches less or more than the actual distance driven due to inertial position relative to the center of the robot
// if the robot is going to move backwards, add 1.13 inches to the desired distance due the the reason given above
//if you are moving forwards, subtract 1.13 inches
/*
void No_Auton(){
  
}

void Red_RHS(){
  DriveTrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  DriveTrain.driveFor(49.13, inches);
  DriveTrain.turnFor(90, degrees);
  DriveTrain.driveFor(forward, 10.87 ,inches);
}

void Red_LHS(){
  DriveTrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  DriveTrain.driveFor(reverse, 49.13, inches);
  DriveTrain.turnFor(-90, degrees);
  DriveTrain.driveFor(forward, 10.87 ,inches);
}
void Blue_RHS(){
  DriveTrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  DriveTrain.driveFor(reverse, 28, inches);
  wait(0.5, seconds);
  MogoMech1.set(true);
  Intake.spin(forward,100,percent);
  wait(0.5, seconds);
  DriveTrain.turnFor(-225, degrees);
  wait(0.5, seconds);
  DriveTrain.driveFor(forward, 28 ,inches);
  wait(0.5, seconds);
  DriveTrain.turnFor(45,degrees);
  wait(0.5, seconds);
  DriveTrain.driveFor(reverse,24,inches);
  wait(0.5, seconds);
  DriveTrain.turnFor(-45, degrees);
  wait(0.5, seconds);
  DriveTrain.driveFor(forward,28, inches);
  wait(0.5, seconds);
  DriveTrain.turnFor(45, degrees);
  DriveTrain.driveFor(24,inches);
  wait(0.5, seconds);
  DriveTrain.turnFor(180, degrees);
  DriveTrain.driveFor(24,inches);
  wait(0.5, seconds);
  DriveTrain.turnFor(45,degrees);
}

void Blue_LHS(){
  //LadybrownFlip();
  DriveTrain.setDriveVelocity(25, percent);
  intake.spin(forward,100,percent);
  DriveTrain.driveFor(reverse, 31, inches);
  wait(0.5, seconds);
  MogoMech1.set(true);
  wait(0.5, seconds);
  Intake.spin(forward,100,percent);
  wait(0.5, seconds);
  DriveTrain.turnFor(90, degrees);
  wait(0.5, seconds);
  DriveTrain.driveFor(forward, 24 ,inches);
  wait(0.5, seconds);
  DriveTrain.driveFor(reverse,35,inches);
}

void RedRush(){

} 
void BlueRush(){

} 
void Skill_Auton(){
  //LadybrownFlip();
  DriveTrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  DriveTrain.driveFor(forward,10.83,inches);
  DriveTrain.turnFor(-90, degrees);
  DriveTrain.driveFor(reverse,25.13,inches);
  DriveTrain.turnFor(0, degrees);
  }  

*/
#include "vex.h"
//all autons must have distance 1.13 inches less or more than the actual distance driven due to inertial position relative to the center of the robot
// if the robot is going to move backwards, add 1.13 inches to the desired distance due the the reason given above
//if you are moving forwards, subtract 1.13 inches
void No_Auton(){
  
}

void Red_RHS(){
  SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  SmartDrivetrain.driveFor(49.13, inches);
  SmartDrivetrain.turnFor(90, degrees);
  SmartDrivetrain.driveFor(forward, 10.87 ,inches);
}

void Red_LHS(){
  SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  SmartDrivetrain.driveFor(reverse, 49.13, inches);
  SmartDrivetrain.turnFor(-90, degrees);
  SmartDrivetrain.driveFor(forward, 10.87 ,inches);
}
void Blue_RHS(){
  SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  SmartDrivetrain.driveFor(reverse, 28, inches);
  wait(0.5, seconds);
  MogoMech.set(true);
  Intake.spin(forward,100,percent);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(-225, degrees);
  wait(0.5, seconds);
  SmartDrivetrain.driveFor(forward, 28 ,inches);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(45,degrees);
  wait(0.5, seconds);
  SmartDrivetrain.driveFor(reverse,24,inches);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(-45, degrees);
  wait(0.5, seconds);
  SmartDrivetrain.driveFor(forward,28, inches);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(45, degrees);
  SmartDrivetrain.driveFor(24,inches);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(180, degrees);
  SmartDrivetrain.driveFor(24,inches);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(45,degrees);
}

void Blue_LHS(){
  //LadybrownFlip();
  Ladybrown.spinFor(forward, 175,  degrees);
  SmartDrivetrain.setDriveVelocity(25, percent);
  SmartDrivetrain.driveFor(reverse, 33, inches);
  MogoMech.set(false);
  intake.spin(forward,100,percent);
  SmartDrivetrain.turnFor(270 , degrees);
  SmartDrivetrain.driveFor (forward, 24, inches);
  wait(0.5, seconds);
  Intake.spin(forward,100,percent);
  wait(0.5, seconds);
  SmartDrivetrain.turnFor(90, degrees);
  wait(0.5, seconds);
  SmartDrivetrain.driveFor(forward, 24 ,inches);
  wait(0.5, seconds);
  SmartDrivetrain.driveFor(reverse,35,inches);
} 
/*void Blue_LHS(){
  SmartDrivetrain.driveFor( reverse, 47,  inches);
} */

void RedRush(){

} 
void BlueRush(){

} 
void Skill_Auton(){
  //LadybrownFlip();
  SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  SmartDrivetrain.driveFor(forward,10.83,inches);
  SmartDrivetrain.turnFor(-90, degrees);
  SmartDrivetrain.driveFor(reverse,25.13,inches);
  SmartDrivetrain.turnFor(0, degrees);
  }  

