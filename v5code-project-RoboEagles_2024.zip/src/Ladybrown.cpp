#include "vex.h"
void LadybrownMacro(){
  //Ladybrown.spinFor(reverse, 30, degrees);
  Ladybrown.spinToPosition(42.5, degrees);
  //Ladybrown.spinFor(forward, 180, degrees);
}
void LadybrownReset(){
  //Ladybrown.spinFor(reverse, 30, degrees);
  Ladybrown.spinToPosition(2, degrees);
  Controller1.rumble("-.-");
  //Ladybrown.spinFor(forward, 180, degrees);
}

  void LadybrownFlip(){
  Ladybrown.spinTo(255, degrees); 
  //Ladybrown.spinFor(forward, 180, degrees);
}