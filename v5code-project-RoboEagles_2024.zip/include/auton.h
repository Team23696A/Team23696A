void No_Auton();
void Red_LHS();
void Red_RHS();
void Blue_LHS();
void Blue_RHS();
void Skill_Auton();
void BlueRush();
void RedRush();