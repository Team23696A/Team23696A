void LadybrownFlip();
void LadybrownMacro();
void LadybrownReset();