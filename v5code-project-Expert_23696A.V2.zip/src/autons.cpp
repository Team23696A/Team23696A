#include "vex.h"
void No_Auton(){
  
}

void Red_RHS(){
  SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  wait(2, sec);
  SmartDrivetrain.driveFor(forward, 600, mm);
}

void Red_LHS(){
    SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  wait(2, sec);
  SmartDrivetrain.driveFor(forward, 600, mm);
}
void Blue_RHS(){
    SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  wait(2, sec);
  SmartDrivetrain.driveFor(forward, 600, mm);
}

void Blue_LHS(){
    SmartDrivetrain.setDriveVelocity(100, percent);
  intake.spin(forward,100,percent);
  wait(2, sec);
  SmartDrivetrain.driveFor(forward, 600, mm);
}

void Skill_Auton(){

} 
