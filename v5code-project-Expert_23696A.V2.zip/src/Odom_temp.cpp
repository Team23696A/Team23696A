/**
#include <cmath>
#include "vex.h"

constexpr double gear_ratio = ((double)84/60); // Using an 84/60 gear ratio for this example.
constexpr double wheel_radius = 2;
constexpr double wheel_circumference = 2 * M_PI * wheel_radius;
constexpr double start_heading = 90;
constexpr double track_width = 13.75;
constexpr double tracking_wheel_radius = 2;
constexpr double tracking_wheel_circumference = 2 * M_PI * tracking_wheel_radius;

double x = 0;
double y = 0;

void odometry() {
    LeftMotors.resetPosition();
    RightMotors.resetPosition();
    double previous_distance_traveled = 0;
    while (true) {
        double heading = std::fmod((360 - Inertial.heading(vex::degrees)) + start_heading, 360);
        double average_encoder_position = (LeftMotors.position(vex::degrees) + RightMotors.position(vex::degrees)) / 2;
        double distance_traveled = (average_encoder_position / 360) * wheel_circumference * gear_ratio;
        double change_in_distance = distance_traveled - previous_distance_traveled;
        x += change_in_distance * std::cos(heading * (M_PI / 180));
        y += change_in_distance * std::sin(heading * (M_PI / 180));
        previous_distance_traveled = distance_traveled;
        vex::this_thread::sleep_for(10);
    }
}

void trackingWheels() {
    double average_encoder_position = (LeftEncoder.position(vex::degrees) + RightEncoder.position(vex::degrees)) / 2;
    double distance_traveled = (average_encoder_position / 360) * tracking_wheel_circumference;
    double left_distance = (LeftMotors.position(vex::degrees) / 360) * wheel_circumference * external_gear_ratio;
    double right_distance = (LeftMotors.position(vex::degrees) / 360) * wheel_circumference * external_gear_ratio;
    double heading_in_radians = (right_distance - left_distance) / track_width;
    double heading = std::fmod((360 - (heading_in_radians * (180 / M_PI))) + start_heading, 360);
}

void autonomous() {
    // Start our odometry thread.
    // The odometry loop will run in the background while we move.
    vex::thread odometry_thread(odometry);

    // Spin our drivetrain forward for 2 seconds.
    LeftMotors.spin(vex::forward);
    RightMotors.spin(vex::forward);
    vex::wait(2, vex::seconds);
    LeftMotors.stop();
    RightMotors.stop();

    // Print where we ended up on the coordinate plane onto the brain screen.
    Brain.Screen.print("(%f, %f)", x, y);
}**/