#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor leftMotorA = motor(PORT11, ratio6_1, true);
motor leftMotorB = motor(PORT12, ratio6_1, true);
motor leftMotorC = motor(PORT13, ratio6_1, true);
motor_group LeftDriveSmart = motor_group(leftMotorA, leftMotorB, leftMotorC);
motor rightMotorA = motor(PORT18, ratio6_1, false);
motor rightMotorB = motor(PORT19, ratio6_1, false);
motor rightMotorC = motor(PORT20, ratio6_1, false);
motor_group RightDriveSmart = motor_group(rightMotorA, rightMotorB, rightMotorC);
inertial DrivetrainInertial = inertial(PORT17);
smartdrive SmartDrivetrain = smartdrive(LeftDriveSmart, RightDriveSmart, DrivetrainInertial, 299.24, 320, 165, mm, 0.75);
controller Controller1 = controller(primary);
digital_out MogoMech1 = digital_out(Brain.ThreeWirePort.A);
digital_out MogoMech2 = digital_out(Brain.ThreeWirePort.B);
digital_out IntakePiston = digital_out(Brain.ThreeWirePort.C);
motor intake = motor(PORT14, ratio18_1, true);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;
// define variables used for controlling motors based on controller inputs
bool DrivetrainNeedsToBeStopped_Controller1 = true;

// define a task that will handle monitoring inputs from Controller1
int rc_auto_loop_function_Controller1() {
  // process the controller input every 20 milliseconds
  // update the motors based on the input values
  while(true) {
    
    if(RemoteControlCodeEnabled) {
      // calculate the drivetrain motor velocities from the controller joystick axies
      // left = Axis3 + Axis4
      // right = Axis3 - Axis4
      int drivetrainLeftSideSpeed = Controller1.Axis3.position() + Controller1.Axis1.position();
      int drivetrainRightSideSpeed = Controller1.Axis3.position() - Controller1.Axis1.position();
      drivetrainLeftSideSpeed = 0.85 * drivetrainLeftSideSpeed;
      drivetrainRightSideSpeed = 0.85 * drivetrainRightSideSpeed;
      // check if the values are inside of the deadband range
      if (abs(drivetrainLeftSideSpeed) < 5 && abs(drivetrainRightSideSpeed) < 5) {
        // check if the motors have already been stopped
        if (DrivetrainNeedsToBeStopped_Controller1) {
          // stop the drive motors
          LeftDriveSmart.stop();
          RightDriveSmart.stop();
          // tell the code that the motors have been stopped
          DrivetrainNeedsToBeStopped_Controller1 = false;
        }
      } else {
        // reset the toggle so that the deadband code knows to stop the motors next time the input is in the deadband range
        DrivetrainNeedsToBeStopped_Controller1 = true;
      }
      
      // only tell the left drive motor to spin if the values are not in the deadband range
      if (DrivetrainNeedsToBeStopped_Controller1) {
        LeftDriveSmart.setVelocity(drivetrainLeftSideSpeed, percent);
        LeftDriveSmart.spin(forward);
      }
      // only tell the right drive motor to spin if the values are not in the deadband range
      if (DrivetrainNeedsToBeStopped_Controller1) {
        RightDriveSmart.setVelocity(drivetrainRightSideSpeed, percent);
        RightDriveSmart.spin(forward);
      }
    }
    // wait before repeating the process
    wait(20, msec);
  }
  return 0;
}
// Function to calculate current speed in RPM
double calculateCurrentSpeed() {
    // Average the velocities of the motors from both sides of the drivetrain
    double leftSpeed = LeftDriveSmart.velocity(rpm);
    double rightSpeed = RightDriveSmart.velocity(rpm);
    double averageSpeed = (leftSpeed + rightSpeed) / 2.0; // Average speed of both sides
    return averageSpeed;
}

// VEXcode generated functions
void vexcodeInit(void) {
    task rc_auto_loop_task_Controller1(rc_auto_loop_function_Controller1);
    Brain.Screen.print("Device initialization...");
    Brain.Screen.setCursor(2, 1);
    wait(200, msec);
    DrivetrainInertial.calibrate();
    Brain.Screen.print("Calibrating Inertial for Drivetrain");
    while (DrivetrainInertial.isCalibrating()) {
        wait(100, msec);
    }
    Brain.Screen.clearScreen();
    Brain.Screen.setCursor(1, 1);
    wait(50, msec);
    Brain.Screen.clearScreen();
}